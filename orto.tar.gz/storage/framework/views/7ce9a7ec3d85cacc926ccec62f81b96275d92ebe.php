<?php $__env->startSection('container'); ?>
<div id="wrapper">
  <div id="page-wrapper">

    <div class="container-fluid">
      <!-- Page Body Heading -->
      <?php echo $__env->make('admin.template.body-header', ['icons' => $icons], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- End of Body Heading -->

      <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      

      <!-- Table of Data -->
      <div class="row">
          <div class="col-lg-12">
              <h2><?php echo e($title_table); ?></h2>

              <div class="table-responsive">
                  <table class="table table-bordered table-hover" id = "data">
                    <thead>
                        <?php foreach($model_labels as $table_label): ?>
                            <th><?php echo e($table_label); ?></th>
                        <?php endforeach; ?>
                    </thead>
                    <tbody>
                        <?php foreach($earnings as $earning): ?>
                          <tr>
                            <td><?php echo e($earning->date->format('d/m/Y')); ?></td>
                            <td><?php echo e($earning->mount); ?></td>
                            <?php if($earning->department_id != 0): ?>
                              <td><?php echo e($earning->department[0]['name']); ?></td>
                            <?php else: ?>
                              <td><?php echo e(Html::linkRoute('admin.consults.view_doctor', $earning->doctor->name . ' - ' . 
                              $earning->doctor->specs[0]['name'], ['id' => $earning->doctor->id_doctor])); ?></td>
                            <?php endif; ?>
                          </tr>

                        <?php endforeach; ?>
                    </tbody>
                  </table>

                  <?php echo $earnings->render(); ?>

              </div>
          </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
  <script type="text/javascript">
    $(document).ready(function() 
    {
      $('#data').DataTable(
        {
          "language" : {
            "emptyTable": "No Hay Ingresos Registradas",
            "paginate" : {
              "first": "Inicio",
              "previous": "Anterior",
              "next": "Siguiente",
              "last": "Ultima"
            },
            "infoEmpty": "Mostrando 0 de 0 Ingresos Totales",
            "info": "Mostrando _START_ de _TOTAL_ Ingresos",
            "lengthMenu" : "Mostrar _MENU_ Ingresos",
            "search": "Busqueda:",
            "zeroRecords":    "No se han encontrado resultados",
          }
        });
    });
  </script>
  
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>