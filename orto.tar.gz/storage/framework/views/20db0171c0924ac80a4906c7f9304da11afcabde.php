<?php echo Form::model($consult, ['route' => ['admin.consults.update', $consult->id_consult],'method' => 'PUT','class' => 'form-horizontal']); ?>


    <?php echo Form::token(); ?>


    <!-- Input Name -->
    <?php echo Form::label('name', 'Paciente', ['class' => 'control-label', 'id' => 'pacient-name']); ?>

    <?php echo Form::text('name', $consult->pacient['name'] ,['class' => 'form-control', 'readonly' => 'readonly']); ?>


    <!-- Input Ci -->

    <?php echo Form::label('ci', 'Cedula de Identidad', ['class' => 'control-label']); ?>

    <?php echo Form::text('ci', $consult->pacient['ci'], ['class' => 'form-control', 'readonly' => 'readonly']); ?>


    <!-- Select Box Doctors -->

    <?php echo Form::label('doctor', 'Doctor Asignado', ['class' => 'control-label']); ?>

    <?php echo Form::select('doctor', $doctors, null, ['class' => 'form-control']); ?>


    <!-- Date Picker -->
    <?php echo Form::label('consult_date', 'Fecha de Consulta', ['class' => 'control-label']); ?>

    <?php echo Form::text('consult_date', $consult->date_consult->format('d/m/Y'), ['class' => 'form-control', 'id' => 'datepicker']); ?>


    <!-- Input Description -->
    <?php echo Form::label('description', 'Procedimiento Realizado', ['class' => 'control-label']); ?>

    <?php echo Form::text('description', $consult->description, ['placeholder' => 'Descripcion del procedimiento', 'class' => 'form-control']); ?>


    <!-- Input Description -->
    <?php echo Form::label('observations', 'Observaciones', ['class' => 'control-label']); ?>

    <?php echo Form::text('observations', $consult->observations, ['placeholder' => 'Observaciones', 'class' => 'form-control']); ?>


    <!-- Input Amount -->
    <?php echo Form::label('amount', 'Monto', ['class' => 'control-label']); ?>

    <?php echo Form::text('amount', $consult->amount, ['placeholder' => 'Monto pagado', 'class' => 'form-control']); ?>



    <?php echo Form::hidden('pacient_id', $consult->pacient['id_pacient']); ?>


    <br>
  <?php echo Form::submit('Actualizar Datos', ['class' => 'btn btn-success']); ?>

            
<?php echo Form::close(); ?>