<?php $__env->startSection('tittle', 'Registro de Doctores'); ?>


<?php $__env->startSection('container'); ?>


<div id="wrapper">
  <div id="page-wrapper">
    <div class="container-fluid">
      <!-- Page Body Heading -->
      <?php echo $__env->make('admin.template.body-header', ['icons' => $icons], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- End of Body Heading -->
      <div class="row">
        <div class="col-lg-6">

        <?php if(count($errors) > 0): ?>
          <div class="alert alert-danger" role = "alert">
            <ul>
              <?php foreach($errors->all() as $error): ?>
                <li> <?php echo e($error); ?> </li>
              <?php endforeach; ?>
            </ul>
          </div>

        <?php endif; ?>

          <?php echo $__env->make('admin.forms.doctor_create', $specs, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
  <script type="text/javascript">

      var max_count = 3;
      var wrapper = $(".form-horizontal");
      var add_button = $("#add");

      var x = 1;

      $(function() 
      {
        $("#datepicker").datepicker();

        add_button.click(function(e)
        {
          e.preventDefault();

          if(x < max_count)

          {
            x++;
            $(wrapper).append(
              '<br><label for="speciality" class="control-label">Especialidad #' + x + '</label>',
              '<input class="form-control" name="speciality" + x + id="speciality" type="text">',
              '<br><a href = "#" class = "btn btn-danger" id = "#remove">Eliminar</a>'
              );

            
          }

          $("#remove").click(function (e)
            {
              e.preventDefault();
              $(wrapper).children().last().remove();
            });

        });

      });

  </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>