<?php echo Form::open(['class' => 'form-horizontal', 'action' => 'PacientsController@store', 'method' => 'POST']); ?>


            <?php echo csrf_field(); ?>


            <!-- Input Name -->
            <?php echo Form::label('name', 'Nombre Completo', ['class' => 'control-label', 'id' => 'pacient-name']); ?>

            <?php echo Form::text('name', null ,['placeholder' => 'Ej: Antonio Berti', 'class' => 'form-control']); ?>


            <!-- Input Ci -->

            <?php echo Form::label('ci', 'Cedula de Identidad', ['class' => 'control-label']); ?>

            <?php echo Form::text('ci', null, ['placeholder' =>  'Ej: V-24.409.499', 'class' => 'form-control']); ?>


            <!-- Input Phone -->

            <?php echo Form::label('phone', 'Telefono', ['class' => 'control-label']); ?>

            <?php echo Form::text('phone', null, ['placeholder' => 'Ej: 04262766415', 'class' => 'form-control']); ?>


            <!-- Input Phone -->

            <?php echo Form::label('phone2', 'Telefono 2', ['class' => 'control-label']); ?>

            <?php echo Form::text('phone2', null, ['placeholder' => 'Ej: 04262766415', 'class' => 'form-control']); ?>


            <!-- Input Address -->
            <?php echo Form::label('address', 'Direccion', ['class' => 'control-label']); ?>

            <?php echo Form::text('address', null, ['placeholder' => 'Ej: Calle Colon', 'class' => 'form-control']); ?>


            <!-- Input Phone -->

            <?php echo Form::label('email', 'Correo Electronico', ['class' => 'control-label']); ?>

            <?php echo Form::email('email', null, ['placeholder' => 'Ej: tplaza15@gmail.com', 'class' => 'form-control']); ?>


            <!-- Input Sex -->
            <?php echo Form::label('sex', 'Sexo', ['class' => 'control-label']); ?>

            <?php echo Form::select('sex', ['M' => 'Masculino', 'F' => 'Femenino'], 'M', ['class' => 'form-control']); ?>

            

            <!-- Input Birth Date -->
            <?php echo Form::label('birth_date', 'Fecha de Nacimiento', ['class' => 'control-label']); ?>

            <?php echo Form::text('birth_date', null, ['class' => 'form-control', 'id' => 'datepicker']); ?>

            <br>
          <?php echo Form::submit('Registar Paciente', ['class' => 'btn btn-primary']); ?>

            
<?php echo Form::close(); ?>