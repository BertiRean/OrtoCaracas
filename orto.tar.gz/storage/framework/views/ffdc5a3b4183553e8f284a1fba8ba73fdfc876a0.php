<!-- Page Heading -->
<div class="row">
  <div class="col-lg-12">
    <h1 class="page-header">
      Bienvenido 
    </h1>
    <ol class="breadcrumb">
      <li class="active">
        <i class="fa fa-dashboard"></i> Inicio
      </li>
      <?php foreach($icons as $icon => $i_label): ?>
        <li>
            <i class="<?php echo e($icon); ?>"></i> <?php echo e($i_label); ?>

        </li>
      <?php endforeach; ?> 
    </ol>
  </div>
</div>
