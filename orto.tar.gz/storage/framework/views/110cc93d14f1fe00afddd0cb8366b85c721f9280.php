<?php $__env->startSection('container'); ?>
<div id="wrapper">
  <div id="page-wrapper">

    <div class="container-fluid">
      <!-- Page Body Heading -->
      <?php echo $__env->make('admin.template.body-header', ['icons' => $icons], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- End of Body Heading -->

      <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      

      <?php echo e(Html::link('/admin/doctor/create', $button_create, ['class' => 'btn btn-success'])); ?>

      <?php echo e(Html::link('#', $button_delete, ['class' => 'btn btn-danger', 'id' => 'delete'])); ?>


      <!-- Table of Data -->
      <div class="row">
          <div class="col-lg-12">
              <h2><?php echo e($title_table); ?></h2>

              <div class="table-responsive">
                  <table class="table table-bordered table-hover" id = "data">
                    <thead>
                        <?php foreach($model_labels as $table_label): ?>
                            <th><?php echo e($table_label); ?></th>
                        <?php endforeach; ?>
                    </thead>

                    <tbody>
                        <?php foreach($doctors as $doctor): ?>
                          <tr>
                            <td><?php echo e(Html::linkRoute('admin.consults.view_doctor', $doctor->name, ['id' => $doctor->id_doctor])); ?></td>
                            <td><?php echo e($doctor->ci); ?></td>

                            <!-- Show Phones -->
                            <?php foreach($doctor->specs as $spec): ?>

                              <td><?php echo e($spec["name"]); ?></td>

                            <?php endforeach; ?>

                            <?php foreach($doctor->phones as $phone): ?>
                              <td><?php echo e($phone["phone_number"]); ?></td>
                            <?php endforeach; ?>
                            <!-- End of Shows -->
                            <td>
                              <?php echo e($doctor->contact["address"]); ?>

                            </td>
                            <td><?php echo e($doctor->bank_account); ?></td>
                            <td><?php echo e($doctor->contact["email"]); ?> </td>
                            <td>
                              <?php echo link_to_route('admin.doctor.edit', $title = 'Editar', $parameters = $doctor->id_doctor, $attributes = ['class' => 'btn btn-primary']); ?>

                              <a href="<?php echo e(url('/admin/doctor', [$doctor->id_doctor])); ?>" data-method="delete" data-token="<?php echo e(csrf_token()); ?>" data-confirm="Esta Seguro?" class="btn btn-danger">Eliminar</a>
                            </td>
                          </tr>
                        <?php endforeach; ?>
                    </tbody>
                  </table>

                  <?php echo $doctors->render(); ?>

              </div>
          </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
  <script type="text/javascript">
    $(document).ready(function() 
    {
      $('#data').DataTable(
        {
          "language" : {
            "emptyTable": "No Hay Doctores Registrados",
            "paginate" : {
              "first": "Inicio",
              "previous": "Anterior",
              "next": "Siguiente",
              "last": "Ultima"
            },
            "infoEmpty": "Mostrando 0 de 0 Doctores Totales",
            "info": "Mostrando _START_ de _TOTAL_ Doctores",
            "lengthMenu" : "Mostrar _MENU_ Doctores",
            "search": "Busqueda:",
            "zeroRecords":    "No se han encontrado resultados",
          }
        });
    });
  </script>
  
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>