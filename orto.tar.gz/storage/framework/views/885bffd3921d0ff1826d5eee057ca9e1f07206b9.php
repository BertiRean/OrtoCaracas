<?php echo Form::model($date, ['route' => ['admin.dates.update', $date->date_id],'method' => 'PUT','class' => 'form-horizontal']); ?>


    <?php echo Form::token(); ?>


    <!-- Input Name -->
    <?php echo Form::label('name', 'Paciente', ['class' => 'control-label', 'id' => 'pacient-name']); ?>

    <?php echo Form::text('name', $date->pacient['name'] ,['class' => 'form-control', 'readonly' => 'readonly']); ?>


    <!-- Input Ci -->

    <?php echo Form::label('ci', 'Cedula del Paciente', ['class' => 'control-label']); ?>

    <?php echo Form::text('ci', $date->pacient['ci'], ['class' => 'form-control', 'readonly' => 'readonly']); ?>


    <!-- Select Box Doctors -->

    <?php echo Form::label('doctor', 'Doctor Asignado', ['class' => 'control-label']); ?>

    <?php echo Form::select('doctor', $doctors, $date->doctor['name'], ['class' => 'form-control']); ?>


    <!-- Date Picker -->
    <?php echo Form::label('consult_date', 'Fecha de Cita', ['class' => 'control-label']); ?>

    <?php echo Form::text('consult_date', $date->date_consult->format('d/m/Y'), ['class' => 'form-control', 'id' => 'datepicker']); ?>



    <?php echo Form::hidden('pacient_id', $date->pacient_id); ?>


    <br>
  <?php echo Form::submit('Actualizar Datos', ['class' => 'btn btn-success']); ?>

            
<?php echo Form::close(); ?>