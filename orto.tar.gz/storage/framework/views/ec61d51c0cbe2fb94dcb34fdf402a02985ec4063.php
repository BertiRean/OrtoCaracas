<?php echo Form::open(['class' => 'form-horizontal', 'action' => 'DatesController@store', 'method' => 'POST']); ?>


    <?php echo Form::token(); ?>


    <!-- Input Name -->
    <?php echo Form::label('name', 'Paciente', ['class' => 'control-label', 'id' => 'pacient-name']); ?>

    <?php echo Form::text('name', $pacient->name ,['class' => 'form-control', 'readonly' => 'readonly']); ?>


    <!-- Input Ci -->

    <?php echo Form::label('ci', 'Cedula de Identidad', ['class' => 'control-label']); ?>

    <?php echo Form::text('ci', $pacient->ci, ['class' => 'form-control', 'readonly' => 'readonly']); ?>


    <!-- Select Box Doctors -->

    <?php echo Form::label('doctor', 'Doctor Asignado', ['class' => 'control-label']); ?>

    <?php echo Form::select('doctor', $doctors, null, ['class' => 'form-control']); ?>


    <!-- Date Picker -->
    <?php echo Form::label('consult_date', 'Fecha de Cita', ['class' => 'control-label']); ?>

    <?php echo Form::text('consult_date', null, ['class' => 'form-control', 'id' => 'datepicker']); ?>



    <?php echo Form::hidden('pacient_id', $pacient->id_pacient); ?>


    <br>
<?php echo Form::submit('Registrar Cita', ['class' => 'btn btn-primary'] ); ?>


            
<?php echo Form::close(); ?>



