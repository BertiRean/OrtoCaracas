<?php $__env->startSection('container'); ?>
<div id="wrapper">
  <div id="page-wrapper">

    <div class="container-fluid">
      <!-- Page Body Heading -->
      <?php echo $__env->make('admin.template.body-header', ['icons' => $icons], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- End of Body Heading -->

      <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      

      <div class="row">
          <div class="col-lg-12">
              <h2><?php echo e($title_table); ?></h2>

              <div class="table-responsive">
                  <table class="table table-bordered table-hover" id = "data">
                    <thead>
                        <?php foreach($model_labels as $table_label): ?>
                            <th><?php echo e($table_label); ?></th>
                        <?php endforeach; ?>
                    </thead>
                    <tbody>
                        <?php foreach($consults as $consult): ?>
                          <tr>
                            <td><?php echo e($consult->doctor["name"] . " - " . $consult->doctor->specs[0]['name']); ?></td>
                            <td><?php echo e($consult->pacient["ci"]); ?></td>
                            <td><?php echo e($consult->date_consult->format('d/m/Y')); ?></td>
                            <td><?php echo e($consult->amount); ?></td>
                            <td><?php echo e($consult->description); ?></td>
                            <td><?php echo e($consult->observations); ?></td>
                          </tr>
                        <?php endforeach; ?>
                    </tbody>
                  </table>

                  <?php echo $consults->render(); ?>

              </div>
          </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
  <script type="text/javascript">
    $(document).ready(function() 
    {
      $('#data').DataTable(
        {
          "language" : {
            "emptyTable": "No Hay Consultas Registradas",
            "paginate" : {
              "first": "Inicio",
              "previous": "Anterior",
              "next": "Siguiente",
              "last": "Ultima"
            },
            "infoEmpty": "Mostrando 0 de 0 Consultas Totales",
            "info": "Mostrando _START_ de _TOTAL_ Consultas",
            "lengthMenu" : "Mostrar _MENU_ Consultas",
            "search": "Busqueda:",
            "zeroRecords":    "No se han encontrado resultados",
          }
        });
    });
  </script>
  
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>