<?php echo Form::open(['class' => 'form-horizontal', 'action' => 'ExpenseController@store', 'method' => 'POST']); ?>


    <?php echo Form::token(); ?>


    <!-- Input Name -->
    <?php echo Form::label('description', 'Nombre', ['class' => 'control-label']); ?>

    <?php echo Form::text('description', null, ['placeholder' => 'Nombre del Egreso', 'class' => 'form-control']); ?>


    <!-- Input Ci -->
    <?php echo Form::label('bill_number', 'Numero de Factura', ['class' => 'control-label']); ?>

    <?php echo Form::text('bill_number', null, ['class' => 'form-control']); ?>


    <!-- Show Actual Date -->
    <?php echo Form::label('date_expense', 'Fecha', ['class' => 'control-label']); ?>

    <?php echo Form::text('date_expense', null, ['class' => 'form-control', 'id' => 'datepicker']); ?>


    <!-- Input Amount -->
    <?php echo Form::label('amount', 'Monto', ['class' => 'control-label']); ?>

    <?php echo Form::text('amount', null, ['placeholder' => 'Coste de la factura', 'class' => 'form-control']); ?>



    <br>
<?php echo Form::submit('Registrar Egreso', ['class' => 'btn btn-primary'] ); ?>


            
<?php echo Form::close(); ?>



