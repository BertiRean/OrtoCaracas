<?php $__env->startSection('tittle', 'Registro de Doctores'); ?>

<?php $__env->startSection('container'); ?>
<div id="wrapper">
  <div id="page-wrapper">

    <div class="container-fluid">
      <!-- Page Body Heading -->
      <?php echo $__env->make('admin.template.body-header', ['icons' => $icons], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- End of Body Heading -->

      <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      
      <!-- Table of Data -->
      <div class="row">
          <div class="col-lg-12">
              <h2><?php echo e($title_table); ?></h2>

              <div class="table-responsive">
                  <table class="table table-bordered table-hover" id = "data">
                    <thead>
                        <?php foreach($model_labels as $table_label): ?>
                            <th><?php echo e($table_label); ?></th>
                        <?php endforeach; ?>
                    </thead>

                    <tbody>
                        <?php foreach($pacients as $pacient): ?>
                          <tr data-id = "<?php echo e($pacient->id_pacient); ?>">
                            <td><?php echo e($pacient->name); ?> </td>
                            <td><?php echo e($pacient->ci); ?></td>
                            <td>
                              <?php echo link_to_route($link_model, $title = $button_text_type, $parameters = [$pacient->id_pacient, $department], $attributes = ['class' => 'btn btn-primary']); ?>

                            </td>
                          </tr>
                        <?php endforeach; ?>
                    </tbody>
                  </table>

                  <?php echo $pacients->render(); ?>

              </div>
          </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
  <script type="text/javascript">
    $(document).ready(function() 
    {
      $('#data').DataTable(
        {
          "language" : {
            "emptyTable": "No Hay Pacientes Registrados",
            "paginate" : {
              "first": "Inicio",
              "previous": "Anterior",
              "next": "Siguiente",
              "last": "Ultima"
            },
            "infoEmpty": "Mostrando 0 de 0 Pacientes Totales",
            "info": "Mostrando _START_ de _TOTAL_ Pacientes",
            "lengthMenu" : "Mostrar _MENU_ Pacientes",
            "search": "Busqueda:",
            "zeroRecords":    "No se han encontrado resultados",
          }
        });
    });
  </script>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>