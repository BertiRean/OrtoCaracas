

<?php echo Form::model($pacient, ['route' => ['admin.pacient.update', $pacient->id_pacient],'method' => 'PUT','class' => 'form-horizontal']); ?>


    <?php echo csrf_field(); ?>


    <!-- Input Name -->
    <?php echo Form::label('name', 'Nombre Completo', ['class' => 'control-label', 'id' => 'pacient-name']); ?>

    <?php echo Form::text('name', null ,['placeholder' => 'Ej: Antonio Berti', 'class' => 'form-control']); ?>


    <!-- Input Ci -->

    <?php echo Form::label('ci', 'Cedula de Identidad', ['class' => 'control-label']); ?>

    <?php echo Form::text('ci', null, ['placeholder' =>  'Ej: V-24.409.499', 'class' => 'form-control']); ?>


    <!-- Input Phone -->
    <?php 
      $count = 1;
    ?>
    <?php foreach($pacient->phones as $phone): ?>
      <?php echo Form::label('phone'.$count, 'Telefono ' . $count, ['class' => 'control-label']); ?>

      <?php echo Form::text('phone'.$count, $phone["phone_number"], ['placeholder' => 'Ej: 04262766415', 'class' => 'form-control']); ?>

      <?php $count  = $count +1;?>
    <?php endforeach; ?>

    <!-- Input Address -->
    <?php echo Form::label('address', 'Direccion', ['class' => 'control-label']); ?>

    <?php echo Form::text('address', $pacient->contact["address"], ['placeholder' => 'Ej: Calle Colon', 'class' => 'form-control']); ?>


    <!-- Input Phone -->

    <?php echo Form::label('email', 'Correo Electronico', ['class' => 'control-label']); ?>

    <?php echo Form::email('email', $pacient->contact["email"], ['placeholder' => 'Ej: tplaza15@gmail.com', 'class' => 'form-control']); ?>


    <!-- Input Sex -->
    <?php echo Form::label('sex', 'Sexo', ['class' => 'control-label']); ?>

    <?php echo Form::select('sex', ['M' => 'Masculino', 'F' => 'Femenino'], $pacient->sex, ['class' => 'form-control']); ?>

    

    <!-- Input Birth Date -->
    <?php echo Form::label('birth_date', 'Fecha de Nacimiento', ['class' => 'control-label']); ?>

    <?php echo Form::text('birth_date', $pacient->birth_date, ['class' => 'form-control', 'id' => 'datepicker']); ?>

    <br>
  <?php echo Form::submit('Actualizar Datos', ['class' => 'btn btn-success']); ?>

            
<?php echo Form::close(); ?>