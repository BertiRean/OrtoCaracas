<!DOCTYPE html>
<html>
  <head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <!-- Bootstrap Core Css -->

    <?php echo Html::style('assets/css/bootstrap.min.css'); ?>


    <!--  Css Style for Admin Panel -->
    <?php echo Html::style('assets/admin/css/sb-admin.css'); ?>


    <!-- Morris Plugin -->

    <?php echo Html::style('assets/admin/css/plugins/morris.css'); ?>


    <!-- Customs Fonts -->

    <?php echo Html::style('assets/admin/font-awesome/css/font-awesome.min.css'); ?>


    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/u/dt/dt-1.10.12/datatables.min.css"/>

    <title>Ortodoncia Caracas - <?php echo $__env->yieldContent('title', 'Inicio'); ?></title> 

  </head>
  
  <body>

    <?php /* Cabecera del Sitio */ ?>
    <!-- Navigation -->
    <?php echo $__env->make('admin.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php /* Cuerpo del Sitio */ ?>

      
    <?php echo $__env->yieldContent('container'); ?>

    <!-- jQuery -->
    <script src = "<?php echo e(asset('/assets/js/jquery-2.2.4.js')); ?>"></script>
    <script src = "<?php echo e(asset('/assets/js/bootstrap.js')); ?>"></script>
    <script src = "<?php echo e(asset('/assets/js/ui/jquery-ui.js')); ?>"></script>

    <!-- Additional Scripts -->


    <!-- jQueryUi Theme -->
    <?php echo Html::style('assets/js/ui/jquery-ui.css'); ?>

    <!-- Bootstrap Core JavaScript -->

    <!-- Morris Charts JavaScript -->

    <?php echo Html::script('assets/admin/js/plugins/morris/raphael.min.js',['type' => 'text/javascript']); ?>


    <script src="/assets/js/laravel.js"></script>

    <script type="text/javascript" src="https://cdn.datatables.net/u/dt/dt-1.10.12/datatables.min.js"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

  </body>
</html>