<?php echo Form::open(['class' => 'form-horizontal', 'action' => 'ExamsController@store', 'method' => 'POST']); ?>


    <?php echo Form::token(); ?>


    <!-- Input Name -->
    <?php echo Form::label('name', 'Paciente', ['class' => 'control-label', 'id' => 'pacient-name']); ?>

    <?php echo Form::text('name', $pacient->name ,['class' => 'form-control', 'readonly' => 'readonly']); ?>


    <!-- Input Ci -->

    <?php echo Form::label('ci', 'Cedula de Identidad', ['class' => 'control-label']); ?>

    <?php echo Form::text('ci', $pacient->ci, ['class' => 'form-control', 'readonly' => 'readonly']); ?>


    <!-- Show Actual Date -->

    <?php echo Form::label('date_exam', 'Fecha de Estudio', ['class' => 'control-label']); ?>

    <?php echo Form::text('date_exam', null, ['class' => 'form-control', 'id' => 'datepicker']); ?>


    <!-- Input Description -->
    <?php echo Form::label('description', 'Descripción', ['class' => 'control-label']); ?>

    <?php echo Form::text('description', null, ['placeholder' => 'Detalles del estudio', 'class' => 'form-control']); ?>


    <!-- Input Amount -->
    <?php echo Form::label('amount', 'Costo del Examen', ['class' => 'control-label']); ?>

    <?php echo Form::text('amount', null, ['placeholder' => 'Costo del estudio', 'class' => 'form-control']); ?>


    <!-- Input Personal -->
    <?php echo Form::label('taked_by', 'Tomado por', ['class' => 'control-label']); ?>

    <?php echo Form::text('taked_by', null, ['placeholder' => 'Nombre del personal', 'class' => 'form-control']); ?>


    <?php echo Form::hidden('pacient_id', $pacient->id_pacient); ?>

    <?php echo Form::hidden('department_id', $department->id_department); ?>


    <br>
<?php echo Form::submit('Registrar Examen', ['class' => 'btn btn-primary'] ); ?>


            
<?php echo Form::close(); ?>



