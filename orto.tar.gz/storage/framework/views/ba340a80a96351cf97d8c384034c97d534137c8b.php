<?php echo Form::model($doctor, ['route' => ['admin.doctor.update', $doctor->id_doctor],'method' => 'PUT','class' => 'form-horizontal']); ?>


    <?php echo Form::token(); ?>


    <!-- Input Name -->
    <?php echo Form::label('name', 'Nombre Completo', ['class' => 'control-label', 'id' => 'doctor-name']); ?>

    <?php echo Form::text('name', $doctor->name ,['class' => 'form-control']); ?>


    <!-- Input Ci -->

    <?php echo Form::label('ci', 'Cedula de Identidad', ['class' => 'control-label']); ?>

    <?php echo Form::text('ci', $doctor->ci, ['class' => 'form-control']); ?>


    <!-- Input Phone -->

    <?php 
        $count = 1;
    ?>

    <?php foreach($doctor->phones as $phone): ?>

      <?php echo Form::label('phone'.$count, 'Telefono ' . $count, ['class' => 'control-label']); ?>

      <?php echo Form::text('phone'.$count, $phone["phone_number"], ['class' => 'form-control']); ?>

      <?php $count++;?>

    <?php endforeach; ?>

    <!-- Input Address -->
    <?php echo Form::label('address', 'Direccion', ['class' => 'control-label']); ?>

    <?php echo Form::text('address', $doctor->contact["address"], ['class' => 'form-control']); ?>


    <!-- Input Phone -->

    <?php echo Form::label('email', 'Correo Electronico', ['class' => 'control-label']); ?>

    <?php echo Form::email('email', $doctor->contact["email"], ['class' => 'form-control']); ?>


    <!-- Input Sex -->
    <?php echo Form::label('bank_account', 'Cuenta Bancaria', ['class' => 'control-label']); ?>

    <?php echo Form::text('bank_account', $doctor->bank_account, ['class' => 'form-control']); ?>


    <?php $count = 1 ?>

    <?php foreach($doctor->specs as $spec): ?>
      <?php echo Form::label('speciality'.$count, 'Especialidad #1', ['class' => 'control-label']); ?>

      <?php echo Form::select('speciality'.$count, $specialities, $spec->name, ['class' => 'form-control']); ?>

      <?php $count++ ?>
    <?php endforeach; ?>

    <br>
  <?php echo Form::submit('Actualizar Datos', ['class' => 'btn btn-success']); ?>

            
<?php echo Form::close(); ?>