<?php $__env->startSection('tittle', 'Editar Paciente ' . $pacient->name); ?>


<?php $__env->startSection('container'); ?>

<div id="wrapper">
  <div id="page-wrapper">
    <div class="container-fluid">
      <!-- Page Body Heading -->
      <?php $icons = ['fa fa-user' => 'Pacientes', 'fa fa-plus-square-o' => 'Editar Paciente'] ?>

      <?php echo $__env->make('admin.template.body-header', ['icons' => $icons], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- End of Body Heading -->
      <div class="row">
        <div class="col-lg-6">

          <?php echo $__env->make('admin.forms.pacient_edit' ,$pacient, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  
  <script type="text/javascript">
      $(function() 
      {
        $("#datepicker").datepicker();
      });

  </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>